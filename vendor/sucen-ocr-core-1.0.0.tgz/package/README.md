# @sucen/ocr-core

商超进销存 **OCR 核心解析库**。纯 TypeScript、零运行时依赖，PC（Vite）/ 移动端（React Native / Expo）/ Node 三端共用。

它将 OCR 的**业务解析逻辑**与**平台副作用**彻底解耦：

- **解析层**：纯函数，直接可用，两端复用同一套识别口径；
- **预处理**：像素算法内置，平台镜像操作通过 `ImageProcessor` 注入；
- **历史存储**：通过 `StorageAdapter` 注入（localStorage / expo-sqlite / 内存）。

---

## 安装

```bash
npm install @sucen/ocr-core
```

- CJS 入口：`dist/cjs/index.js`
- ESM 入口：`dist/esm/index.js`
- 类型声明：`dist/types/index.d.ts`

> 描述里的 "零运行时依赖" 指的是：运行时无需任何第三方库，所有宿主端图片/存储依赖都以依赖注入的方式传入。

---

## 目录结构

```
packages/ocr-core/
├── src/
│   ├── index.ts            # 统一导出
│   ├── fieldNormalizer.ts  # 字段校验与纠错（金额/日期/条码/供应商/商品匹配）
│   ├── ocrParse.ts         # 商品标签 OCR 解析（配料表/营养成分/版式检测）
│   ├── parsePurchaseBill.ts# 进货单解析（版式检测 + 字段纠错 + 置信度）
│   ├── ocrMock.ts          # 占位 mock 实现与类型
│   ├── preprocess/
│   │   ├── pixels.ts       # 纯像素算法（灰度/对比度/亮度/二值化/中值/锐化/边界）
│   │   ├── processor.ts    # ImageProcessor/ImageSurface 抽象 + 类型
│   │   ├── preprocess.ts   # preprocessImage / buildRetryVariants
│   │   └── hash.ts         # hashImage（图像哈希缓存键）
│   ├── ocrHistory.ts       # 识别历史存储
│   └── storage.ts          # StorageAdapter + localStorage/内存适配器
├── tests/                  # 单元测试（vitest）
└── dist/                   # 构建产物（cjs/esm/types）
```

---

## 快速上手

### 1. 商品标签 OCR 解析（纯函数，直接用）

```ts
import { parseOcrText, type OcrResult } from '@sucen/ocr-core';

const text = `XX牌矿泉饮用水
配料：天然饮用水
营养成分表  项目  每100ml  NRV%
能量  0kJ  0%
蛋白质  0g  0%`;
const result: OcrResult = parseOcrText(text);
console.log(result.productName, result.ingredients, result.nutrition);
```

### 2. 进货单解析（纯函数，直接用）

```ts
import { parsePurchaseBill, type PurchaseBill } from '@sucen/ocr-core';

const text = `供应商：华润万家
单号：PO-20260816-001
日期：2026年8月16日
1 农夫山泉 550ml  24瓶  48.00
2 可口可乐 330ml  36罐  54.00
合计：¥102.00`;
const bill: PurchaseBill = parsePurchaseBill(text);
console.log(bill.supplierName, bill.date, bill.total, bill.items.length);
```

### 3. 图片预处理（需注入 `ImageProcessor`）

```ts
import { preprocessImage, buildRetryVariants, type ImageProcessor } from '@sucen/ocr-core';

const myProcessor: ImageProcessor = {
  async load(src, maxEdge) {
    // 宿主端实现：把 src（bytes / base64 / file uri）解码成 ImageSurface
    // 返回 { surface, originalWidth, originalHeight }
    return { surface: surface, originalWidth: w, originalHeight: h };
  },
};

const { surface, dataUrl } = await preprocessImage(imageSrc, myProcessor, { maxEdge: 1280 });
const variants = await buildRetryVariants(imageSrc, myProcessor, { maxEdge: 1280 });
```

> `ImageProcessor` 是唯一的平台差异点。**PC（浏览器）**用 canvas 实现，**移动端（RN）**用 expo-image-manipulator 实现。若平台取不到 `getPixels()`，预处理会优雅降级（跳过像素增强，直接返回原图）。

### 4. 识别历史存储（需注入 `StorageAdapter`）

```ts
import { createOcrHistoryStore, createLocalStorageAdapter } from '@sucen/ocr-core';

const store = createOcrHistoryStore(createLocalStorageAdapter(), {
  storageKey: 'wb_ocr_history',
  maxEntries: 50,
});
store.pushHistory({ id, name, items, createdAt });
const list = store.loadHistory();
```

---

## 依赖注入约束

本库**不直接触碰**浏览器 / Node / RN 的任何全局对象，因此：

| 能力 | 是否内置 | 需注入的接口 |
| --- | --- | --- |
| 文本解析（标签 / 进货单） | ✅ 0 依赖 | 无 |
| 字段校验纠错 | ✅ 0 依赖 | 无 |
| 图片像素增强算法 | ✅ 0 依赖 | 无 |
| 图片加载/解码 | ❌ 平台差异 | `ImageProcessor` |
| 历史存储 | ❌ 平台差异 | `StorageAdapter` |

这样保证了：

- 三端（PC / 移动端 / Node）共用**同一套解析口径**；
- 测试无需 mock `window` / `localStorage`；
- 包体积可控，不含任何平台 polyfill。

---

## 核心 API 速览

### 解析层（纯函数）

| 函数 | 说明 |
| --- | --- |
| `parseOcrText(raw, opts?)` | 解析商品标签 OCR 文本 → `OcrResult` |
| `parsePurchaseBill(raw, opts?)` | 解析进货单 OCR 文本 → `PurchaseBill` |
| `mockOcr()` | 生成示例 `OcrResult` |
| `normalizeAmount(input)` | 金额归一化 → `number \| undefined` |
| `normalizeDate(input, opts?)` | 日期归一化 → `YYYY-MM-DD` |
| `normalizeBarcode(input)` | 条码归一化（EAN8/13，检查位）→ `string \| undefined` |
| `checkBarcode(input)` | 条码校验 → `BarcodeCheck \| undefined` |
| `matchSupplier(items, query)` | 供应商模糊匹配（含评分与阈值） |
| `matchProduct(items, query)` | 商品模糊匹配 |
| `isTrustworthy(conf)` | 置信度是否可信（默认阈值 0.8） |
| `isPlausibleAmount(n)` | 金额是否合理（上限 100 万） |

### 类型

- `OcrResult`、`NutritionItem`、`LabelLayout`
- `PurchaseBill`、`BillItem`、`PurchaseBillConfidence`、`BillLayout`
- `BarcodeCheck`、`MatchResult<T>`

### 预处理层

| 函数 / 类型 | 说明 |
| --- | --- |
| `preprocessImage(src, processor, opts)` | 单图预处理，返回 `PreprocessResult`（含 `surface`/`dataUrl`） |
| `buildRetryVariants(src, processor, opts)` | 生成重试变体（锐化/二值化/强提亮）用于降级链 |
| `hashImage(src)` | 图像哈希（用于 24h 缓存键） |
| `toGrayscale` / `autoContrast` / `autoBrightness` | 纯像素算法，可直接组合 |
| `otsuThreshold` / `medianFilter` / `sharpen` / `binarize` | 同上 |
| `detectContentBounds` | 内容边界检测 |
| `ImageProcessor` / `ImageSurface` / `LoadedSurface` | 平台注入接口 |
| `PreprocessOptions` / `PreprocessResult` / `ImageVariant` | 预处理类型 |

### 历史存储层

| 函数 / 类型 | 说明 |
| --- | --- |
| `createOcrHistoryStore(storage, opts?)` | 创建历史 store |
| `createLocalStorageAdapter()` | localStorage 适配器（浏览器） |
| `createMemoryStorageAdapter()` | 内存适配器（测试 / Node） |
| `StorageAdapter` | 同步存储接口 |

---

## 面向宿主端的注入示例

### PC（Vite / 浏览器）—— `ImageProcessor` 用 canvas

```ts
import { preprocessImage, type ImageProcessor, type ImageSurface } from '@sucen/ocr-core';

function toCanvas(img: HTMLImageElement, maxEdge: number) { /* ... */ }
function wrapCanvas(canvas: HTMLCanvasElement, ctx: CanvasRenderingContext2D): ImageSurface { /* ... */ }

export const canvasImageProcessor: ImageProcessor = {
  async load(src, maxEdge) {
    const img = await loadImage(src);
    const { canvas, ctx } = toCanvas(img, maxEdge);
    return {
      surface: wrapCanvas(canvas, ctx),
      originalWidth: img.naturalWidth || img.width,
      originalHeight: img.naturalHeight || img.height,
    };
  },
};
```

### 移动端（React Native / Expo）—— `ImageProcessor` 用 expo-image-manipulator

```ts
// Surface.getPixels() 取不到时返回 null，预处理会优雅降级（不崩）
import { ImageManipulator } from 'expo-image-manipulator';

export const rnImageProcessor: ImageProcessor = {
  async load(src, maxEdge) {
    // RN 拿不到像素数组，这里只做缩放 + base64，不做像素级增强
    return { surface: rnSurface, originalWidth: w, originalHeight: h };
  },
};
```

---

## 开发

```bash
npm run build   # tsc 出类型 + esbuild 出 cjs/esm（含 dist/esm/package.json 标记）
npm test        # vitest 单元测试（74 用例）
npm pack        # 打出 tgz，供两端 npm install
```

`scripts/build.js` 用 esbuild 做**单文件打包**（ESM+CJS 双格式），再写一个 `dist/esm/package.json` 标记 `{"type":"module"}`，避免 Node 在 ESM 下解析 extensionless relative import 时报错。

---

## 测试覆盖

`tests/` 下的单测全部迁移自 PC 端 `retail-admin/src/utils`，三套件共 **74 用例**：

- `fieldNormalizer.test.ts`（35）：金额/日期/条码/供应商/商品匹配
- `ocrParse.test.ts`（16）：标签解析 + 版式检测
- `parsePurchaseBill.test.ts`（23）：进货单解析 + 版式 + 置信度 + 字段纠错

两端各自还有包集成冒烟测试（PC 端 `src/utils/ocrCore.smoke.test.ts`）。

---

## 兼容性说明

- `parseOcrText(text)` / `parsePurchaseBill(text)` 的单参调用签名**保持不变**，移动端 `OcrImageScreen` / `EntryForm` 无需改调用逻辑，仅替换 import 路径。
- 旧 `parseOcrText` 的低置信度字段保护、版式检测均已纳入本包。
- 移动端旧版 `src/utils/ocrParse.ts` / `ocrMock.ts` / `parsePurchaseBill.ts` 已作为死代码备份移除，逻辑统一从本包加载。
